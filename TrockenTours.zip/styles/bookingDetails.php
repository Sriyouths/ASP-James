<?php   
header("Content-type: text/css");
?>

container {
    border: 2px solid red;
  border-radius: 5px;
}